# FantaFormation 3.1 — miglioramenti implementati

Data: 23 settembre 2026

## 1. Inserimento formazione più veloce
- Dopo il click sul giocatore, l'automazione verifica direttamente lo slot appena aggiornato.
- Ridotti i tempi di attesa nella ricerca del giocatore.
- Eliminata l'attesa fissa della chiusura completa del drawer prima di passare al giocatore successivo.
- Ridotti i ritardi nella navigazione verso la pagina di inserimento formazione.

## 2. Agente locale per la scelta della formazione
- Aggiunto un layer `AgentDecision` che analizza la copertura reale di statistiche, probabili, news e consigli raccolti online.
- La strategia viene adattata tra `PRUDENTE`, `EQUILIBRATO` e `BONUS + FORMA`.
- Il motore confronta le formazioni disponibili e prova combinazioni dei migliori candidati; l'agente modifica il punteggio in base a rischio titolarità e strategia dati.
- Non è richiesta una chiave API: il comportamento è locale e deterministico.

## 3. Widget + automazione ricorrente in background
- Il widget avvia direttamente il flusso automatico.
- Aggiunto uno scheduler settimanale basato su `AlarmManager` con exact alarm quando autorizzato.
- La pianificazione viene ripristinata dopo reboot, aggiornamento app, cambio ora e cambio fuso.
- Per Android 14/15 sono presenti gli opt-in per l'avvio di Activity da background tramite `PendingIntent`.
- Il foreground service mantiene attivo il processo durante l'automazione e usa un partial wakelock limitato a 45 minuti.

## Limite tecnico attuale
La compilazione APK non è stata eseguita in questo ambiente perché il progetto caricato non contiene il Gradle wrapper e nel container non sono disponibili Gradle/Android SDK. Sono stati comunque effettuati controlli statici sulle sorgenti e sul manifest: XML valido, parentesi Java bilanciate, nessun duplicato di classe/metodo rilevato, e nessun errore sintattico Java rilevato dal parser `javac` (i soli errori sono dovuti all'assenza delle librerie Android nel container).

L'automazione WebView resta volutamente dentro `MainActivity`: il percorso widget/scheduler può avviare l'esecuzione senza che l'utente debba aprire manualmente l'app, ma non è una soluzione headless completamente priva di Activity.
